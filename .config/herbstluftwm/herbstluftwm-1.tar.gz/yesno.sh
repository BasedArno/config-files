#!/bin/bash

printf "Yes\nNo\n"

response="$@"

echo "$response" 1>&2

exit
