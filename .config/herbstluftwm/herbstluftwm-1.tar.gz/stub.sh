#!/bin/bash

response="$@"

echo "$response" 1>&2

exit
